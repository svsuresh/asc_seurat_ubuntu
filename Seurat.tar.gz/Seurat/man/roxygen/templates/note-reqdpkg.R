#' @note This function requires the
#' \href{https://cran.r-project.org/package=<%= pkg %>}{\pkg{<%= pkg %>}} package
#' to be installed
